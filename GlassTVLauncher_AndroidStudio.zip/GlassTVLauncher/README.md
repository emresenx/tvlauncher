# Glass TV Launcher

Gerçek Android TV launcher başlangıç projesi. Java, Android SDK ve Gradle ile hazırlanmıştır.

## APK oluşturma
1. Android Studio'da bu klasörü **Open** ile açın.
2. Gradle senkronizasyonunu tamamlayın (internet gerekir).
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin.
4. Çıktı: `app/build/outputs/apk/debug/app-debug.apk`.
5. APK'yı Android TV'ye yükleyin. Cihaz destekliyorsa HOME tuşunda varsayılan ana ekranı seçin.

## Özellikler
- Leanback ve normal launcher kategorilerinden yüklü uygulamaları bulur; kumanda ile seçilip açılabilir.
- Beş tema kalıcı olarak kaydedilir.
- Antalya hava durumu Open-Meteo üzerinden çekilir; bağlantı yoksa şehir adı görünür.
- Android TV ayarlarına geçiş.
- Canlı Kanallar kısayolu cihazdaki TV uygulamasını bulmaya çalışır; bulunamazsa uyarı gösterir.

## Sınırlamalar
- Bu dosya derlenmiş APK değildir; Android Studio projesidir.
- Android TV cihaz üreticisi varsayılan launcher değiştirmeyi kısıtlayabilir.
- Canlı TV uygulaması algılama üreticiye göre değişir.
- Android TV'de yüklü olmayan uygulamalar listelenmez.
- Uygulama ikonları cihazda yüklü paketlerden alınır; bazıları üreticinin ikonuyla görünür.
- Hava durumu için internet gereklidir.
