package com.glasstv.launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.net.*;
import java.io.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
 final int[] colors={0xff547a98,0xff648e7d,0xff8885b3,0xff9b7183,0xffa4948c};
 final String[] names={"Buz Mavisi","Adaçayı","Lavanta","Gül Kurusu","Kum Beji"};
 LinearLayout root, header, apps; TextView weather; int themeIndex; android.content.SharedPreferences prefs;
 int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
 GradientDrawable bg(int color,int radius,int stroke){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{lighten(color,0.12f),color,darken(color,0.14f)});g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
 int lighten(int c,float p){return Color.rgb(Math.min(255,(int)(Color.red(c)+(255-Color.red(c))*p)),Math.min(255,(int)(Color.green(c)+(255-Color.green(c))*p)),Math.min(255,(int)(Color.blue(c)+(255-Color.blue(c))*p)));}
 int darken(int c,float p){return Color.rgb((int)(Color.red(c)*(1-p)),(int)(Color.green(c)*(1-p)),(int)(Color.blue(c)*(1-p)));}
 TextView txt(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(null,1);return t;}
 LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
 LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
 void focus(View v){v.setFocusable(true);v.setOnFocusChangeListener((view,has)->{view.setScaleX(has?1.055f:1);view.setScaleY(has?1.055f:1);view.setElevation(dp(has?12:2));view.setAlpha(has?1:.95f);});}
 @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("glass",0);themeIndex=prefs.getInt("theme",0);draw();}
 void draw(){int base=colors[themeIndex];root=col();root.setPadding(dp(32),dp(22),dp(32),dp(18));root.setBackground(bg(base,0,0x00ffffff));setContentView(root);
 header=row();root.addView(header,new LinearLayout.LayoutParams(-1,dp(55)));TextView title=txt("Android TV  ◉",27,true);header.addView(title,new LinearLayout.LayoutParams(0,-1,1));
 weather=txt("☁  Antalya  ···",16,false);weather.setPadding(dp(15),0,dp(15),0);weather.setBackground(bg(0x557f9cae,22,0x66ffffff));header.addView(weather,new LinearLayout.LayoutParams(-2,dp(40)));
 TextView settings=txt("  ⚙  ",24,true);header.addView(settings);focus(settings);settings.setOnClickListener(v->openSettings());
 TextView time=txt("  "+new java.text.SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),18,false);header.addView(time);
 LinearLayout promos=row();LinearLayout.LayoutParams pr=new LinearLayout.LayoutParams(-1,0,1.1f);pr.topMargin=dp(13);root.addView(promos,pr);
 LinearLayout live=feature("Canlı\nKanallar","▶  Şimdi İzle",0x667c9eb6);LinearLayout.LayoutParams f1=new LinearLayout.LayoutParams(0,-1,1);f1.rightMargin=dp(12);promos.addView(live,f1);focus(live);live.setOnClickListener(v->openTv());
 LinearLayout youtube=feature("▶ YouTube","▶  Hemen Başla",0xff9d1822);promos.addView(youtube,new LinearLayout.LayoutParams(0,-1,1));focus(youtube);youtube.setOnClickListener(v->launch("com.google.android.youtube.tv"));
 HorizontalScrollView shortcuts=new HorizontalScrollView(this);shortcuts.setHorizontalScrollBarEnabled(false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(68));sp.topMargin=dp(14);root.addView(shortcuts,sp);LinearLayout buttons=row();shortcuts.addView(buttons);
 String[] labs={"⚙  Ayarlar","◉  Ağ ve İnternet","▣  Görüntü ve Ses","ⓘ  Cihaz Tercihleri","◉  Hesaplar","▤  Girişler","▣  Ebeveyn Denetimi"};for(int i=0;i<labs.length;i++){final int index=i;TextView t=txt(labs[i],15,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(16),0,dp(16),0);t.setBackground(bg(0x667f9aab,15,0x77ffffff));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,dp(52));bp.rightMargin=dp(7);buttons.addView(t,bp);focus(t);t.setOnClickListener(v->{if(index==0)openSettings();else try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception e){toast("Ayarlar açılamadı");}});}
 TextView section=txt("Uygulamalarım",21,true);LinearLayout.LayoutParams sec=new LinearLayout.LayoutParams(-1,dp(46));sec.topMargin=dp(6);root.addView(section,sec);
 HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setClipToPadding(false);scroll.setHorizontalScrollBarEnabled(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));apps=row();apps.setGravity(Gravity.TOP);scroll.addView(apps);loadApps();updateWeather();}
 LinearLayout feature(String title,String action,int color){LinearLayout v=col();v.setPadding(dp(23),dp(16),dp(15),dp(18));v.setBackground(bg(color,22,0x88ffffff));TextView a=txt(title,29,true);v.addView(a,new LinearLayout.LayoutParams(-1,0,1));TextView b=txt(action,16,false);v.addView(b);return v;}
 void loadApps(){PackageManager pm=getPackageManager();LinkedHashMap<String,ResolveInfo> found=new LinkedHashMap<>();for(String cat:new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER,Intent.CATEGORY_LAUNCHER}){Intent q=new Intent(Intent.ACTION_MAIN);q.addCategory(cat);for(ResolveInfo r:pm.queryIntentActivities(q,0)){if(!r.activityInfo.packageName.equals(getPackageName()))found.put(r.activityInfo.packageName,r);}}
 ArrayList<ResolveInfo> list=new ArrayList<>(found.values());Collections.sort(list,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));if(list.isEmpty()){apps.addView(txt("Uygulama bulunamadı",18,false));return;}
 for(ResolveInfo info:list){String pkg=info.activityInfo.packageName;LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(9),dp(12),dp(9),dp(12));tile.setBackground(bg(0x88556b80,19,0xaaffffff));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(150),dp(183));lp.rightMargin=dp(11);apps.addView(tile,lp);
 ImageView icon=new ImageView(this);try{icon.setImageDrawable(info.loadIcon(pm));}catch(Exception ignored){}icon.setScaleType(ImageView.ScaleType.FIT_CENTER);tile.addView(icon,new LinearLayout.LayoutParams(dp(88),dp(105)));
 TextView label=txt(String.valueOf(info.loadLabel(pm)),15,true);label.setGravity(Gravity.CENTER);label.setMaxLines(2);tile.addView(label,new LinearLayout.LayoutParams(-1,dp(46)));focus(tile);tile.setOnClickListener(v->launch(pkg));}}
 void launch(String pkg){try{PackageManager pm=getPackageManager();Intent i=pm.getLeanbackLaunchIntentForPackage(pkg);if(i==null)i=pm.getLaunchIntentForPackage(pkg);if(i==null){toast("Bu uygulama açılamıyor");return;}startActivity(i);}catch(Exception e){toast("Uygulama açılamadı");}}
 void openTv(){Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);PackageManager pm=getPackageManager();for(ResolveInfo r:pm.queryIntentActivities(i,0)){String p=r.activityInfo.packageName.toLowerCase(Locale.ROOT);if(p.contains("tv")||p.contains("live")){launch(r.activityInfo.packageName);return;}}toast("Canlı TV uygulaması bulunamadı");}
 void openSettings(){String[] options={"Buz Mavisi","Adaçayı","Lavanta","Gül Kurusu","Kum Beji","Android Ayarları"};new AlertDialog.Builder(this).setTitle("Görünüm ve Ayarlar").setItems(options,(d,which)->{if(which<5){themeIndex=which;prefs.edit().putInt("theme",which).apply();draw();}else try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception e){toast("Ayarlar açılamadı");}}).show();}
 void updateWeather(){new Thread(()->{String result="☁  Antalya";HttpURLConnection c=null;try{URL u=new URL("https://api.open-meteo.com/v1/forecast?latitude=36.8969&longitude=30.7133&current=temperature_2m,weather_code&timezone=Europe%2FIstanbul");c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(7000);c.setReadTimeout(7000);StringBuilder sb=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()))){String s;while((s=r.readLine())!=null)sb.append(s);}JSONObject o=new JSONObject(sb.toString()).getJSONObject("current");int code=o.getInt("weather_code");String sym=(code==0?"☀":code<4?"⛅":code>=51?"☂":"☁");result=sym+"  Antalya  "+Math.round(o.getDouble("temperature_2m"))+"°C";}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}final String value=result;runOnUiThread(()->{if(weather!=null)weather.setText(value);});}).start();}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
